# Website trắc nghiệm: Quy trình nghiên cứu khoa học

## Chạy trên máy bằng VS Code
1. Giải nén thư mục.
2. Mở VS Code → File → Open Folder… → chọn thư mục `quiz_nghien_cuu_khoa_hoc`.
3. Mở `index.html`.
4. Nếu đã cài tiện ích Live Server: bấm chuột phải vào `index.html` → **Open with Live Server**. Nếu chưa có, bạn vẫn có thể mở `index.html` trực tiếp bằng trình duyệt.

## Đưa website lên GitHub Pages
1. Đăng nhập https://github.com/
2. Bấm dấu **+** → **New repository**.
3. Đặt tên repository, ví dụ `quiz-nghien-cuu-khoa-hoc`, chọn **Public** → **Create repository**.
4. Trong repository, chọn **Add file → Upload files**.
5. Kéo 3 file `index.html`, `style.css`, `script.js` (có thể thêm `README.md`) lên. Chú ý: `index.html` phải nằm ngay ở thư mục gốc của repository.
6. Bấm **Commit changes**.
7. Vào **Settings → Pages**.
8. Trong **Build and deployment**, chọn **Deploy from a branch**; Branch chọn **main**, thư mục chọn **/(root)**; bấm **Save**.
9. Chờ một lúc rồi tải lại trang Pages. Đường dẫn thường có dạng `https://TEN-TAI-KHOAN.github.io/TEN-REPOSITORY/`.

## Tạo mã QR
1. Sao chép đường dẫn GitHub Pages sau khi website đã mở được.
2. Mở một công cụ tạo QR đáng tin cậy, dán đường dẫn, tạo và tải QR dạng PNG.
3. Dùng điện thoại quét thử trước khi in hoặc đưa vào bài thuyết trình.

## Chỉnh sửa nội dung
- Sửa câu hỏi và đáp án trong mảng `questions` ở file `script.js`.
- Sửa màu sắc, bố cục trong file `style.css`.
- Sửa tiêu đề và phần giới thiệu trong file `index.html`.
