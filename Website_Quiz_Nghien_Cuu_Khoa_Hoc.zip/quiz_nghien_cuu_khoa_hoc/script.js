const questions = [
  {
    stage: "Thử thách 1 · Giai đoạn chuẩn bị",
    question: "Một nhóm sinh viên đang xây dựng khung đề tài. Họ lúng túng khi xác định đâu là khách thể, đâu là đối tượng nghiên cứu. Nhóm cần làm rõ khái niệm nào?",
    options: ["Đối tượng và phạm vi nghiên cứu", "Mục đích và nội dung nghiên cứu", "Phương pháp và nội dung nghiên cứu", "Mục đích và phương pháp nghiên cứu"],
    answer: 1,
    explanation: "Theo nội dung bài trình chiếu, đáp án được đánh dấu là B: Mục đích và nội dung nghiên cứu."
  },
  {
    stage: "Thử thách 2 · Văn bản định hướng",
    question: "Một nhóm nghiên cứu có ý tưởng tốt nhưng chưa có văn bản định hướng rõ ràng. Nhóm đang thiếu văn bản nào?",
    options: ["Có đề cương - Thiếu kế hoạch", "Có kế hoạch - Thiếu đề cương", "Có báo cáo - Thiếu kế hoạch", "Có đề cương - Thiếu nhật ký nghiên cứu"],
    answer: 1,
    explanation: "Đáp án được đánh dấu trong bài trình chiếu là B: Có kế hoạch - Thiếu đề cương."
  },
  {
    stage: "Thử thách 3 · Giai đoạn triển khai",
    question: "Trong quá trình triển khai, một sinh viên đưa ra kết luận nhưng không thu thập đủ dữ liệu thực tế để chứng minh. Đây là vấn đề gì?",
    options: ["Không giải thích được sự vật, hiện tượng", "Không đủ khả năng kiểm chứng bằng thực nghiệm", "Không có tính đột phá về mặt lý luận", "Không phù hợp với quỹ thời gian của nhóm"],
    answer: 1,
    explanation: "Đáp án được đánh dấu trong bài trình chiếu là B: Không đủ khả năng kiểm chứng bằng thực nghiệm."
  },
  {
    stage: "Thử thách 4 · Xử lý dữ liệu",
    question: "Một sinh viên thu thập được 100 phiếu khảo sát nhưng chỉ chọn các phiếu ủng hộ ý kiến của mình để đưa vào báo cáo. Đây là lỗi nào?",
    options: ["Bỏ qua bước tổng hợp dữ liệu thô", "Vi phạm tính khách quan, chủ quan áp đặt ý đồ bản thân", "Không sử dụng công cụ thống kê kỹ thuật số", "Lựa chọn sai đối tượng để phỏng vấn"],
    answer: 1,
    explanation: "Đáp án được đánh dấu trong bài trình chiếu là B: Vi phạm tính khách quan, chủ quan áp đặt ý đồ bản thân."
  },
  {
    stage: "Thử thách 5 · Báo cáo và kiểm chứng",
    question: "Vì sao cần đối chiếu kết quả nghiên cứu với nhiều nguồn hoặc góc nhìn trước khi kết luận?",
    options: ["Để chứng minh các nghiên cứu trước đó sai hoàn toàn", "Để đối phó với các câu hỏi của Hội đồng Khoa học", "Để đảm bảo tính đa chiều và tránh sai lầm trước khi kết luận", "Để làm tăng dung lượng cho bản báo cáo cuối cùng"],
    answer: 2,
    explanation: "Đáp án được đánh dấu trong bài trình chiếu là C: Để đảm bảo tính đa chiều và tránh sai lầm trước khi kết luận."
  }
];

let current = 0;
let score = 0;
let answered = false;
const stageEl = document.getElementById("stage");
const questionEl = document.getElementById("question");
const answersEl = document.getElementById("answers");
const feedbackEl = document.getElementById("feedback");
const nextBtn = document.getElementById("nextBtn");
const progressText = document.getElementById("progressText");
const progressBar = document.getElementById("progressBar");
const questionCard = document.getElementById("questionCard");
const result = document.getElementById("result");

function renderQuestion() {
  answered = false;
  const q = questions[current];
  stageEl.textContent = q.stage;
  questionEl.textContent = q.question;
  answersEl.innerHTML = "";
  feedbackEl.textContent = "";
  nextBtn.disabled = true;
  nextBtn.textContent = current === questions.length - 1 ? "Xem kết quả →" : "Câu tiếp theo →";
  progressText.textContent = `Câu ${current + 1}/${questions.length}`;
  progressBar.style.width = `${((current + 1) / questions.length) * 100}%`;
  q.options.forEach((option, index) => {
    const button = document.createElement("button");
    button.className = "answer";
    button.textContent = `${String.fromCharCode(65 + index)}. ${option}`;
    button.addEventListener("click", () => chooseAnswer(index, button));
    answersEl.appendChild(button);
  });
}

function chooseAnswer(index, selectedButton) {
  if (answered) return;
  answered = true;
  const q = questions[current];
  const buttons = [...answersEl.querySelectorAll("button")];
  buttons.forEach((button, i) => {
    button.disabled = true;
    if (i === q.answer) button.classList.add("correct");
  });
  if (index === q.answer) {
    score++;
    feedbackEl.textContent = `Chính xác! ${q.explanation}`;
  } else {
    selectedButton.classList.add("wrong");
    feedbackEl.textContent = `Chưa đúng. ${q.explanation}`;
  }
  nextBtn.disabled = false;
}

nextBtn.addEventListener("click", () => {
  if (!answered) return;
  if (current < questions.length - 1) {
    current++;
    renderQuestion();
  } else {
    questionCard.classList.add("hidden");
    result.classList.remove("hidden");
    document.getElementById("resultTitle").textContent = `Bạn đạt ${score}/${questions.length} điểm`;
    document.getElementById("resultText").textContent =
      score === questions.length ? "Xuất sắc! Bạn đã nắm vững các ý chính trong bài." :
      "Hãy xem lại phần giải thích của từng câu và thử lại để ghi nhớ tốt hơn.";
  }
});

document.getElementById("restartBtn").addEventListener("click", () => {
  current = 0;
  score = 0;
  result.classList.add("hidden");
  questionCard.classList.remove("hidden");
  renderQuestion();
});

renderQuestion();
